#include "MyDemoApp.hpp"

int main() {
	auto app = MyDemoApp("MyDemoApp", 1920, 1080);

	app.show();
	app.runLoop();
}