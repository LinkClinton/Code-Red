#include <DemoApp.hpp>

class DemoApp final : public Demo::DemoApp {
public:
	DemoApp(
		const std::string &name, 
		const size_t width, 
		const size_t height) :
		Demo::DemoApp(name, width, height) {}
private:
	void update() override {}
	void render() override {}
	void initialize() override {}
};

int main() {
	auto app = DemoApp("Demo", 1920, 1080);
	
	app.show();
	app.runLoop();
}